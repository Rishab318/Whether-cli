import readline from "node:readline";
import https from "node:https";
// import * as dotenv from "dotenv";

// dotenv.config();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const apiKey = "3f87628c0ccc221a4e1b273e435b9125";
const baseURL = "api.openweathermap.org";

function getCoordinates(
  city: string
): Promise<{ lat: number; lon: number; name: string }> {
  return new Promise((resolve, reject) => {
    const url = `/geo/1.0/direct?q=${city}&limit=1&appid=${apiKey}`;

    const requestOptions = {
      hostname: baseURL,
      port: 443,
      path: url,
      method: "GET",
    };

    const req = https.request(requestOptions, (res) => {
      let data = "";

      res.on("data", (chunk) => {
        data += chunk;
      });

      res.on("end", () => {
        try {
          const json = JSON.parse(data);
          if (json.length > 0) {
            const { lat, lon, name } = json[0];
            resolve({ lat, lon, name });
          } else {
            reject("City not found");
          }
        } catch (error) {
          reject("Error: Unable to parse coordinate data.");
        }
      });
    });

    req.on("error", (e) => {
      reject(`Error: ${e.message}`);
    });

    req.end();
  });
}

function getWeather(lat: number, lon: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = `/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;

    const requestOptions = {
      hostname: baseURL,
      port: 443,
      path: url,
      method: "GET",
    };

    const req = https.request(requestOptions, (res) => {
      let data = "";

      res.on("data", (chunk) => {
        data += chunk;
      });

      res.on("end", () => {
        try {
          const json = JSON.parse(data);
          if (json.cod === 200) {
            const description = json.weather[0].description;
            const temperature = json.main.temp;
            resolve(
              `The weather is currently ${description} with a temperature of ${temperature}°C in ${json.name}.`
            );
          } else {
            resolve(`Error: ${json.message}`);
          }
        } catch (error) {
          resolve("Error: Unable to parse weather data.");
        }
      });
    });

    req.on("error", (e) => {
      resolve(`Error: ${e.message}`);
    });

    req.end();
  });
}

rl.question("Enter the city name: ", async (city) => {
  try {
    const { lat, lon, name } = await getCoordinates(city);
    console.log(`Coordinates for ${name}: Latitude ${lat}, Longitude ${lon}`);

    rl.question("Enter the latitude: ", (latitude) => {
      rl.question("Enter the longitude: ", async (longitude) => {
        const weatherInfo = await getWeather(
          parseFloat(latitude),
          parseFloat(longitude)
        );
        console.log(weatherInfo);
        rl.close();
      });
    });
  } catch (error) {
    console.log(error);
    rl.close();
  }
});
